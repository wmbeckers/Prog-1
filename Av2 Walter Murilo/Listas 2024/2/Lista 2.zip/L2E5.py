numero = int(input("Digite um número inteiro: "))
resultado = "Par" if numero % 2 == 0 else "Ímpar"
print(f"O número {numero} é {resultado}.")